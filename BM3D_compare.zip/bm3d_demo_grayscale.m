% Grayscale BM3D denoising demo file, based on
% Y. Mäkinen, L. Azzari, A. Foi, 2020,
% "Collaborative Filtering of Correlated Noise: Exact Transform-Domain Variance for Improved Shrinkage and Patch Matching",
% in IEEE Transactions on Image Processing, vol. 29, pp. 8339-8354.
% K. Dabov, A. Foi, V. Katkovnik, K. Egiazarian, 2007,
% "Image Denoising by Sparse 3-D Transform-Domain Collaborative Filtering",
% in IEEE Transactions on Image Processing, vol. 16, pp. 2080-2095.

% ---
% The location of the BM3D files -- this folder only contains demo data
clc;clear;close all;
y=readTIF('simulated_GT.tif'); 
%% gold nano-particles' contrast usually detected under 0.3, here we set the contrast at 0.3 
baseline=0.3;
y=y*baseline;

% Possible noise types to be generated 'gw', 'g1', 'g2', 'g3', 'g4', 'g1w',
% 'g2w', 'g3w', 'g4w'.
noise_type =  'gw';
noise_var = 0.0001; % Noise variance
seed = 0; % seed for pseudorandom noise realization
% Generate noise with given PSD
[noise, PSD, kernel] = getExperimentNoise(noise_type, noise_var, seed, size(y));
% N.B.: For the sake of simulating a more realistic acquisition scenario,
% the generated noise is *not* circulant. Therefore there is a slight
% discrepancy between PSD and the actual PSD computed from infinitely many
% realizations of this noise with different seeds.

% Generate noisy image corrupted by additive spatially correlated noise
% with noise power spectrum PSD
z = y + noise;

for i=1:100
    [noise, PSD, kernel] = getExperimentNoise(noise_type, noise_var, seed, size(y));
    z1_0(:,:,i) = y + noise;
end

z1=getAverage(z1_0);

z2=getNotched1(z,[21 21],41,0.08,520,0.3,10,baseline);

% Call BM3D With the default settings.
y_est = BM3D(z, PSD);

nn=5;
a(:,:,1)=y;
a(:,:,2)=z;
a(:,:,3)=y_est;
a(:,:,4)=z1;
a(:,:,5)=z2;
a1=normalMaxMin(a);

s=size(a,1);
s1=round((s+1)/2);
for i=1:size(a,3)
    c(:,i)=a(s1,:,i);
end
figure;
xx=1:s;
xx=0.080*xx;
hold on;
colors={'k','--k','--b','--m','--r'};
for i=1:size(a,3)
    plot(xx,c(:,i),colors{i});
end
xlabel('Position / \mum'); ylabel('Cross section intensity');
legend('Ground truth','Blurred','BM3D','Averaging','Our method');
set(gca,'FontName','Helvetica','FontSize',32);
xticks([0 1.5 3]);
xticklabels({'0', '1.5', '3'});
yticks([0.27 0.30 0.33]);
yticklabels({'0.27', '0.30', '0.33'});
hold off;

b=imtile(a1,'GridSize',[1 nn],'BorderSize',1,'BackgroundColor','k');

figure;
imshow(b,[]);


%% home-made functions to normalise image with the maximum and the minimum intensity
function a=normalMaxMin(a)
    for i=1:size(a,3)
        mins=min(min(a(:,:,i)));
        maxs=max(max(a(:,:,i)));
        a(:,:,i)=(a(:,:,i)-mins)/(maxs-mins);
    end
end
%% home-made functions to load tiff stack image
function file=readTIF(filename)   
    sizef=size(imfinfo(filename),1);
    file = imread(filename, 1); 
    for idx = 2 : sizef
        tiffTemp = imread(filename, idx);
        file = cat(3 , file, tiffTemp);
    end 
    file=double(file);
end
%% our filter to enhance the momentum feather (bright-dark-rings)
function e=getNotched1(a,p,npixel,pixelsize,wavelength,na,r,baseline)   
    %% a parameter in line 115 was introduced to compensate for intensity loss of the
    %% Fourier domain filter, since any components in Fourier domain
    %% contribute to the particle intensity and back ground noise intensity
    %% an optimal compensate parameter was determined by reaching the highest
    %% structure similarity index measure (SSIM) score with the ground truth
    m_compensate=4;
    for i=1:size(a,3)
        %% apply the filter in the frequency domain
        b=fftshift(fft2(a(:,:,i)));
        mask=NotchFilter( npixel,pixelsize,wavelength,na,0,0 );
        c=b.*mask;
        d=real(ifft2(fftshift(c)));
        %% compensate the intensity with parameter in line 115
        [amean,~]=getBackgrounds(d,p,r);
        e(:,:,i)=baseline+m_compensate*(d-amean);
    end
end

%% BM3D functions download from github, which were attached here in one matlab script
function [noise, PSD, kernel] = getExperimentNoise(noise_type, noise_var, realization, sz)
    % randn('seed',realization);
    randn();
    
    % Get pre-specified kernel
    kernel = getExperimentKernel(noise_type, noise_var, sz);
    
    % Create noisy image
    half_kernel = ceil(size(kernel) ./ 2);
    if(numel(sz) == 3 && numel(half_kernel) == 2)
        half_kernel(3) = 0;
    end
    
    % Crop edges
    noise = convn(randn(sz + 2 * half_kernel), kernel(end:-1:1,end:-1:1, :), 'same');
    noise = noise(1+half_kernel(1):end-half_kernel(1), 1+half_kernel(2):end-half_kernel(2), :);
    
    PSD = abs(fft2(kernel, sz(1), sz(2))).^2 * sz(1) * sz(2);
end
function kernel = getExperimentKernel(noiseType, noiseVar, sz)
    % Case gw / g0
    kernel = ones(1);
    
    noiseTypes = {'gw', 'g0', 'g1', 'g2', 'g3', 'g4', 'g1w', 'g2w', 'g3w', 'g4w'};
    
    found = false;
    for nt = noiseTypes
        if strcmp(noiseType, nt)
            found = true;
        end
    end
    if ~found
        disp('Error: Unknown noise type!')
        return;
    end
    
    if (~strcmp(noiseType, 'g4') && ~strcmp(noiseType, 'g4w')) || ~exist('sz', 'var')
        % Crop this size of kernel when generating,
        % unless pink noise, in which
        % Case we want to use the full image size
        sz = [101, 101];
       
    end
    
    % Sizes for meshgrids
    sz2 = -(1 - mod(sz, 2)) * 1 + floor(sz/2);
    sz1 = floor(sz/2);
    [uu, vv] = meshgrid(-sz1(1):sz2(1), -sz1(2):sz2(2)); 
    alpha = 0.8;
    
    switch (noiseType(1:2))
        case 'g1'
            % Horizontal line
            kernel = 16 - abs((1:31)-16);
            
        case 'g2'
            % Circular repeating pattern
            scale = 1;
            dist = (uu).^2 + (vv).^2;
            kernel = cos(sqrt(dist) / scale) .* fspecial('gaussian', [sz(1), sz(2)], 10);
            
        case 'g3' 
            % Diagonal line pattern kernel
            scale = 1;
            kernel = cos((uu + vv) / scale) .* fspecial('gaussian', [sz(1), sz(2)], 10);    
            
        case 'g4'
            % Pink noise
            dist = (uu).^2 + (vv).^2;
            n = sz(1)*sz(2);
            spec3 = sqrt((sqrt(n)*1e-2)./(sqrt(dist) +  sqrt(n)*1e-2));
            kernel = fftshift(ifft2(ifftshift(spec3)));
    end    
    
    % -- Noise with additional white component --
    if numel(noiseType) == 3 && noiseType(3) == 'w'
        kernel = kernel / norm(kernel(:));
        kalpha = sqrt((1 - alpha) + (alpha) * abs(fft2(kernel, sz(1), sz(2))).^2);
        kernel = fftshift(ifft2(kalpha));
    end
    
    % Correct variance
    kernel = kernel / norm(kernel(:)) * sqrt(noiseVar);
end
function [y_est, blocks] = BM3D(z, sigma_psd, profile, stage_arg, blockmatches)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  BM3D is an algorithm for attenuation of additive spatially correlated
%  stationary (aka colored) Gaussian noise in grayscale and multichannel images.
%
%
%  FUNCTION INTERFACE:
%
%  y_est = BM3D(z, sigma_psd, profile)
%
%  INPUT ARGUMENTS:
%
%  -- required --
%
%         'z' : noisy image (M x N or M x N x C double array, intensities in range [0,1])
%               For multichannel images, block matching is performed on the first channel.
%  'sigma_psd' : noise power spectral density (M x N double nonnegative array)
%               OR
%               noise STD
%               OR
%               either of these in multichannel:
%               (M x N x C PSDs or 1 x C STDs)
%
% -- optional --
%
%   'profile' : 'np' --> Normal Profile (default)
%               'refilter' --> Apply refiltering
%               OR
%               a BM3DProfile object specifying the parameters
%               some other premade profiles also included from the previous versions
%               in BM3DProfile.m
%
%   'stage_arg' : Determines whether to perform hard-thresholding or wiener filtering.
%                 either BM3DProfile.HARD_THRESHOLDING, BM3DProfile.ALL_STAGES or an estimate
%                  of the noise-free image.
%                    - BM3DProfile.ALL_STAGES: Perform both.
%                    - BM3DProfile.HARD_THRESHOLDING: Perform hard-thresholding only.
%                    - ndarray, size of z: Perform Wiener Filtering with stage_arg as pilot.
%
%   'blockmatches' : Tuple {HT, Wiener}, with either value either:
%                      - false : Do not save blockmatches for phase
%                      (default)
%                      - true : Save blockmatches for phase
%                      - Pre-computed block-matching array returned by a
%                      previous call with [true]
%  OUTPUT:
%      'y_est'  denoised image  (M x N double array)
%      'y_est', {'blocks_ht', 'blocks_wie'} denoised image, plus HT and
%          Wiener blockmatches, if any storeBM values are set to True
%          (or [0] for missing block array, if only one calculated)
%
%
%  BASIC SIMULATION EXAMPLES:
%
%     Case 1)
%
%      % Read a grayscale noise-free image
%
%      y=im2double(imread('cameraman.tif'));
%
%      % Generate noisy observations corrupted by additive colored random noise
%        generated as convution of AWGN against with kernel 'k'
%
%      k=[-1;2;-1]*[1 4 1]/100;   % e.g., a diagonal kernel
%      z=y+imfilter(randn(size(y)),k(end:-1:1,end:-1:1),'circular');
%
%      % define 'sigma_psd' from the kernel 'k'
%
%      sigma_psd=abs(fft2(k,size(z,1),size(z,2))).^2*numel(z);
%
%      % Denoise 'z'
%      y_est = BM3D(z, sigma_psd);
%
%
%     Case 2)
%
%      % Read a grayscale noise-free image
%
%      y=im2double(imread('cameraman.tif'));
%
%      % Generate noisy observations corrupted by additive colored random noise
%      % generated as convution of AWGN against with kernel 'k'
%      [x2, x1]=meshgrid(ceil(-size(y,2)/2):ceil(size(y,2)/2)-1,ceil(-size(y,1)/2):ceil(size(y,1)/2)-1)
%      sigma_psd=ifftshift(exp(-((x1/size(y,1)).^2+(x2/size(y,2)).^2)*10))*numel(y)/100;
%      z=y+real(ifft2(fft2(randn(size(y))).*sqrt(sigma_psd)/sqrt(numel(y))));
%
%      % Denoise 'z'
%      y_est = BM3D(z, sigma_psd);
%
%     Case 3) If 'sigma_psd' is a singleton, this value is taken as sigma and
%             it is assumed that the noise is white variance sigma^2.
%
%      % Read a grayscale noise-free image
%
%      y=im2double(imread('cameraman.tif'));
%
%      % Generate noisy observations corrupted by additive white Gaussian noise with variance sigma^2
%      sigma=0.1;
%      z=y+sigma*randn(size(y));
%
%      y_est = BM3D(z, sigma);
%
%      % or, equivalently,
%      sigma_psd = ones(size(z))*sigma^2*numel(z)
%      y_est = BM3D(z, sigma_psd)
%
%
%      Case 4)   MULTICHANNEL PROCESSING
%
%      y_est = BM3D(cat(3, z1, z2, z3), sigma_psd, 'np'); 
%
%      Multiple PSDs are optionally handled in the same way.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Copyright (c) 2006-2019 Tampere University.
% All rights reserved.
% This work (software, material, and documentation) shall only
% be used for nonprofit noncommercial purposes.
% Any unauthorized use of this work for commercial or for-profit purposes
% is prohibited.
%
% AUTHORS:
%     Y. Mäkinen, L. Azzari, K. Dabov, A. Foi
%     email: ymir.makinen@tuni.fi
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ~exist('profile','var')
        profile         = 'np'; %% default profile
    end
    
    if isa(profile, 'string') || isa(profile, 'char')
        profile = BM3DProfile(profile);
    end
    
    if ~exist('stage_arg','var')
        stage_arg = profile.ALL_STAGES;  % By default, do both HT and Wie
    end
    
    if min(size(z, 1), size(z, 2)) < profile.N1 || min(size(z, 1), size(z, 2)) < profile.N1_wiener
        disp('Error: Image cannot be smaller than block size!')
        return
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    pro = convertToBM4DProfile(profile);
    
    channel_count = size(z, 3);
    dont_do_bm = ~exist('blockmatches','var') || numel(blockmatches) ~= 2 || ...
                    (blockmatches{1} == false && blockmatches{2} == false);
    
    if channel_count > 1  % Channel dimension should be 4
        z = permute(z, [1, 2, 4, 3]);
        if ndims(sigma_psd) == 3
            sigma_psd = permute(sigma_psd, [1, 2, 4, 3]);
        end
    
        if ~dont_do_bm
            disp('Warning: block-match data supplied with multichannel BM3D will be discarded. Call the function separately for each channel.');
        end
        [y_est] = BM4D_multichannel(z, sigma_psd, pro, stage_arg);
        y_est = squeeze(y_est);
        return
    end
    
    if dont_do_bm
        [y_est] = BM4D(z, sigma_psd, pro, stage_arg);
    else
        [y_est, blocks] = BM4D(z, sigma_psd, pro, stage_arg, blockmatches);
    end

end

function pro = convertToBM4DProfile(pro_in)
    pro = BM4DProfile('BM3D');

    pro.filter_strength = pro_in.filter_strength;

    pro.print_info = pro_in.print_info;

    pro.transform_3D_HT_name = pro_in.transform_2D_HT_name;
    pro.transform_3D_Wiener_name = pro_in.transform_2D_Wiener_name;
    pro.transform_NL_name = pro_in.transform_3rd_dim_name;

    pro.Nf = [pro_in.Nf, pro_in.Nf, 1];
    pro.Kin = pro_in.Kin;

    pro.denoise_residual = pro_in.denoise_residual;
    pro.residual_thr = pro_in.residual_thr;
    pro.max_pad_size = pro_in.max_pad_size;

    pro.gamma = pro_in.gamma;

    pro.N1 = [pro_in.N1, pro_in.N1, 1];
    pro.Nstep = [pro_in.Nstep, pro_in.Nstep, 1];

    pro.N2 = pro_in.N2;
    pro.Ns = [floor(pro_in.Ns / 2), floor(pro_in.Ns / 2), 0];
    pro.tau_match = pro_in.tau_match * pro_in.N1^2 / 255^2;

    pro.lambda_thr = pro_in.lambda_thr3D;
    pro.mu2 = pro_in.mu2;

    pro.lambda_thr_re = pro_in.lambda_thr3D_re;
    pro.mu2_re = pro_in.mu2_re;
    pro.beta = pro_in.beta;

    pro.N1_wiener = [pro_in.N1_wiener, pro_in.N1_wiener, 1];
    pro.Nstep_wiener = [pro_in.Nstep_wiener, pro_in.Nstep_wiener, 1];

    pro.N2_wiener = pro_in.N2_wiener;
    pro.Ns_wiener = [floor(pro_in.Ns_wiener / 2), floor(pro_in.Ns_wiener / 2), 0];
    pro.tau_match_wiener = pro_in.tau_match_wiener * pro_in.N1_wiener^2 / 255^2;
    pro.beta_wiener = pro_in.beta_wiener;
    pro.decLevel = pro_in.decLevel;

    pro.set_sharpen(pro_in.sharpen_alpha);
    pro.num_threads = pro_in.num_threads;

end

function psnr = getCroppedPSNR(y, y_est, half_kernel)
    psnr = getPSNR(y(half_kernel(1)+1:end-half_kernel(1), half_kernel(2)+1:end-half_kernel(2), :), ...
        y_est(half_kernel(1)+1:end-half_kernel(1), half_kernel(2)+1:end-half_kernel(2), :));
end
function PSNR = getPSNR(y, y_est)
    if length(size(y)) == 2
        PSNR = 10*log10(1/mean(mean((y-y_est).^2)));   
    else
        PSNR = 10*log10(1/(mean(mean(mean((y-y_est).^2)))));    
    end
end